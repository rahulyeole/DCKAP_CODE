﻿using DCKAP.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace DCKAP.Controllers
{
    public class ValuesController : ApiController
    {

        Database__Operations.dbo db = new Database__Operations.dbo();

        public IEnumerable<string> Get()
        {
            return new string[] { "Hello REST API", "I am Authorized" };

           
        }

        // GET api/WebApi/5
        public string Get(int id)
        {
            return "Hello Authorized API with ID = " + id;
        }
        /// <summary>
        /// Post method to insert data in Customer Master Table
        /// </summary>
        /// <param name="cm"></param>
        /// <returns></returns>
        [HttpPost]
        public IHttpActionResult AddCustomerMaster([FromBody] CustomerMaster cm)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                db.Add_Customer(cm);
                return Ok("Success");

            }
            catch (Exception)
            {
                return Ok("Something went wrong, try later");
            }       
        }


        /// <summary>
        /// Post method to insert data in Item Master Table
        /// </summary>
        /// <param name="im"></param>
        /// <returns></returns>
        [HttpPost]
        public IHttpActionResult AddItemMaster([FromBody] ItemMaster im)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                db.Add_ItemMaster(im);
                return Ok("Success");

            }
            catch (Exception)
            {
                return Ok("Something went wrong, try later");
            }
        }

        /// <summary>
        /// Post method to insert data in Sales Order Header
        /// </summary>
        /// <param name="soh"></param>
        /// <returns></returns>


        [HttpPost]
        public IHttpActionResult AddSalesOrderHeader([FromBody] SalesOrderHeader soh)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                db.Add_SalesOrderHeader(soh);
                return Ok("Success");

            }
            catch (Exception)
            {
                return Ok("Something went wrong, try later");
            }
        }

        [HttpDelete]
        public IHttpActionResult DeletePersonalDetails(int id)
        {
            try 
            {
               
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                db.Delete_ItemMaster(id);
                return Ok("Success");

            }
            catch (Exception)
            {
                return Ok("Something went wrong, try later");
            }

        }



    }
}
