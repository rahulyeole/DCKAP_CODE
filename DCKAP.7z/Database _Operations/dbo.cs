﻿using DCKAP.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DCKAP.Database__Operations
{
    public class dbo
    {

	  SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);

        /// <summary>
        /// Add Customer Master
        /// </summary>
        /// <param name="cm"></param>
        public void Add_Customer(CustomerMaster cm)
        {
            SqlCommand sc = new SqlCommand("CustomerMaster", con);
            sc.CommandType = CommandType.StoredProcedure;

            sc.Parameters.AddWithValue("@customername",cm.customername);
            sc.Parameters.AddWithValue("@address",cm.address);
            sc.Parameters.AddWithValue("@state",cm.state);
            sc.Parameters.AddWithValue("@zipcode",cm.zipcode);
            sc.Parameters.AddWithValue("@street",cm.street);
            sc.Parameters.AddWithValue("@country",cm.country);
            sc.Parameters.AddWithValue("@phone",cm.phone);
            sc.Parameters.AddWithValue("@email",cm.email);
            con.Open();
            sc.ExecuteNonQuery();
            con.Close();
 
        }

        public void Add_ItemMaster(ItemMaster IM)
        {
            SqlCommand sc = new SqlCommand("ItemMaster", con);
            sc.CommandType = CommandType.StoredProcedure;

            sc.Parameters.AddWithValue("@itemcode",IM.itemcode);
            sc.Parameters.AddWithValue("@itemname",IM.itemname);
            sc.Parameters.AddWithValue("@quantityonhand",IM.quantityonhand);
            sc.Parameters.AddWithValue("@price",IM.price );
            sc.Parameters.AddWithValue("@webenabled",IM.webenabled);

            con.Open();
            sc.ExecuteNonQuery();
            con.Close();
        }
        public void Add_SalesOrderHeader(SalesOrderHeader SOH)
        {
            SqlCommand sc = new SqlCommand("salesorderline", con);
            sc.CommandType = CommandType.StoredProcedure;
            sc.Parameters.AddWithValue("@customername", SOH.customername);
            sc.Parameters.AddWithValue("@docdate", SOH.docdate);
            sc.Parameters.AddWithValue("@postingdate", SOH.postingdate);
            sc.Parameters.AddWithValue("@address", SOH.address);
            sc.Parameters.AddWithValue("@doctotal", SOH.doctotal);
            sc.Parameters.AddWithValue("@state", SOH.state);
            sc.Parameters.AddWithValue("@zipcode", SOH.zipcode);
            sc.Parameters.AddWithValue("@street", SOH.street);
            sc.Parameters.AddWithValue("@country", SOH.country);
            sc.Parameters.AddWithValue("@referencenumber", SOH.referencenumber);
            sc.Parameters.AddWithValue("@ordernum", SOH.ordernum);
            sc.Parameters.AddWithValue("@salesperson", SOH.salesperson);
            con.Open();
            sc.ExecuteNonQuery();
            con.Close();
        }

        public void Delete_ItemMaster(int id)
        {
            SqlCommand sc = new SqlCommand("DeleteItemMaster", con);
            sc.CommandType = CommandType.StoredProcedure;
            sc.Parameters.AddWithValue("@imid", id);
            con.Open();
            sc.ExecuteNonQuery();
            con.Close();
        }

        public void LoginByUsernamePassword(string username, string password)
        {
            SqlCommand sc = new SqlCommand("LoginByUsernamePassword", con);
            sc.CommandType = CommandType.StoredProcedure;
            sc.Parameters.AddWithValue("@username", username);
            sc.Parameters.AddWithValue("@password", password);


            con.Open();
            sc.ExecuteNonQuery();
            con.Close();
        }

    }
}