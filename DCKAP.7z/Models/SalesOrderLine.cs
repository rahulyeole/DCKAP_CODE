﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCKAP.Models
{
    public class SalesOrderLine
    {

        /// <summary>
        /// SalesOrderLine
        /// </summary>
        public string itemno { get; set; }

        public int quantityordered { get; set; }

        public string price { get; set; }

        public string linetotal { get; set; }
    }
}