﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCKAP.Models
{
    public class SalesOrderHeader
    {
        /// <summary>
        /// SalesOrderHeader
        /// </summary>
        public string customername { get; set; }

        public DateTime docdate { get; set; }

        public DateTime postingdate { get; set; }

        public string address { get; set; }

        public string doctotal { get; set; }

        public string state { get; set; }

        public string zipcode { get; set; }

        public string street { get; set; }

        public string country { get; set; }

        public string referencenumber { get; set; }

        public string ordernum { get; set; }

        public string salesperson { get; set; }




    }
}