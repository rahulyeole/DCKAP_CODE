﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCKAP.Models
{
    public class ItemMaster
    {
        /// <summary>
        /// Item Master 
        /// </summary>
        public int imid { get; set; }
        public string itemcode { get; set; }

        public string itemname { get; set; }

        public string quantityonhand { get; set; }

        public int price { get; set; }

        public bool webenabled { get; set; }

    }
}